import java.util.*;
public class PredefinedInterfaceDemo {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("Banana", "Apple", "Cherry");
        Collections.sort(list);
        System.out.println(list);
    }
}
