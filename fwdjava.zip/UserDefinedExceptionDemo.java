class MyException extends Exception {
    MyException(String msg) { super(msg); }
}
