class Parent {
    void greet() { System.out.println("Hello"); }
}
class Child extends Parent {
    void speak() { System.out.println("Hi!"); }
}
