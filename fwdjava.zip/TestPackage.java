import mypack.Message;
public class TestPackage {
    public static void main(String[] args) {
        new Message().show();
    }
}
