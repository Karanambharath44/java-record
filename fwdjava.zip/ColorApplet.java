import java.applet.*;
import java.awt.*;
public class ColorApplet extends Applet {
    public void paint(Graphics g) {
        setBackground(Color.CYAN);
        g.setColor(Color.RED);
        g.fillOval(40, 40, 60, 60);
    }
}
