// package java;

public class jp{
	public static void main(String[] args){
		char a=65;
		System.out.println(a);
	 
		}

}
