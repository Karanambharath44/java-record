public class StringHandlingDemo {
    public static void main(String[] args) {
        String str = "Hello";
        System.out.println("Length: " + str.length());
        System.out.println("Upper: " + str.toUpperCase());
    }
}
