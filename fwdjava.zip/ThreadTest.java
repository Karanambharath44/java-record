class MyThread extends Thread {
    public void run() { System.out.println("Thread running"); }
}
public class ThreadTest {
    public static void main(String[] args) {
        new MyThread().start();
    }
}
